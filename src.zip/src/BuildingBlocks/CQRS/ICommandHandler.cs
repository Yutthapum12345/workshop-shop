using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace src.BuildingBlocks.CQRS;
{
    public interface ICommandHandler<in TCommand, Unit> : IRequestHandler<TCommand, Unit> where TCommand : ICommandHandler<Unit>
    {
    }
}

