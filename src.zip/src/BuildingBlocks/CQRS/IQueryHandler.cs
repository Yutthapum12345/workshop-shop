using System;
using System.Threading.Tasks;

namespace src.BuildingBlocks.CQRS
{
    public interface IQueryHandler<in TQuery, TResponse> : IRequestHandler<TQuery, TResponse> where TQuery : IQuery<TResponse>
    {
        
        Task<TResponse> Handle(TQuery query);
    }
}
