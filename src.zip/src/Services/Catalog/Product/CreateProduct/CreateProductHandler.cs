
using BuildingBlocks.CQRS;
using MediatR;
namespace Catalog.API.Product.CreateProduct;

public record CreateProductCommand(string Name,List<string> Catagory);



public class CreateProductCommand : IRequestHandler<CreateProductCommand,CreateProductResult>
{
    public async Task<CreateProductResult>Handle(CreateProductCommand request,CancellationToken cancellationToken)
    {

        public void AddRoutes(IEndpointRouteBuilder app)
        {
            app.MapPost("/products",async (CreateProductRequest request, ISender sender)=>
            {

                    throw new NotImplementedExceptions();
            }
            
            )
    
        }
    }
}







