using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Category.API.Product.GerProducts
{
    public record GetProductQuery() : IQuery<List<Product>>;

    public record GetProductsResult(IEnumerable<Product> Products);

    public class GetProductHandler : IQueryHandler<GetProductQuery, GetProductsResult>
    {
        public Task<GetProductsResult> Handle(GetProductQuery query)
        {
            
            throw new NotImplementedException();
        }
    }
}
