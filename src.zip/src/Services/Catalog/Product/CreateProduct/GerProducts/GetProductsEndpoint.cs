

namespace Catalog.API.Products.GerProducts;

public record GetProductsEndpoint :CreateEndpoint

    public class GetProductsEndpoint: IE
    {
        
    }
