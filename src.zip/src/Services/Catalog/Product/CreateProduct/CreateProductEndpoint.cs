


namespace Catalog.API.Product.CreateProduct;

public record CreateProductEndpoint(string Name,List<string> Catagory);



public class CreateProductEndpoint : IRequestHandler<CreateProductCommand,CreateProductResult>
{
    public async Task<CreateProductResult>Handle(CreateProductCommand request,CancellationToken cancellationToken)
    {

        public void AddRoutes(IEndpointRouteBuilder app)
        {
            app.MapPost("/products",async (CreateProductRequest request, ISender sender)=>
            {

                var response - await sender.Send(

                    new CreateProductCommand(request.Name,
                    request.Catagory
                ));
                return new CreateProductResponse(Guid.NewGuid());

                    throw new NotImplementedExceptions();
            })
    
        }
    }
}






